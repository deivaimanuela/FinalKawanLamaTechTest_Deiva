package kawanLamaTechTest
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

import org.openqa.selenium.WebElement
import org.openqa.selenium.WebDriver
import org.openqa.selenium.By

import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory
import com.kms.katalon.core.webui.driver.DriverFactory

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObjectProperty

import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper
import com.kms.katalon.core.util.KeywordUtil

import com.kms.katalon.core.webui.exception.WebElementNotFoundException

import cucumber.api.java.en.And
import cucumber.api.java.en.Given
import cucumber.api.java.en.Then
import cucumber.api.java.en.When



class MakeAppointmentStepDef {
	/**
	 * The step definitions below match with Katalon sample Gherkin steps
	 */
	@Given("User already on Make Appointment Page")
    def user_on_make_appointment_page() {
		WebUI.verifyTextPresent('Make Appointment', false)
	}

    @And("selects facility {string}")
    def select_facility(String facility) {
		WebUI.selectOptionByValue(findTestObject('Object Repository/Page_CURA Healthcare Service/select_Tokyo CURA Healthcare Center        _5b4107'),
			'Hongkong CURA Healthcare Center', true)
	}

    @And("sets hospital readmission to {string}")
    def set_readmission(String readmission) {
        def checkbox = findTestObject('Page_CURA Healthcare Service/input_Apply for hospital readmission_hospit_63901f'')
        if (readmission == 'Yes') {
            WebUI.check(checkbox)
        } else {
            WebUI.uncheck(checkbox)
        }
    }

    @And("chooses healthcare program {string}")
    def choose_healthcare_program(String program) {
        switch (program.toLowerCase()) {
            case "medicare":
                WebUI.click(findTestObject('Page_CURA Healthcare Service/input_Medicare_programs'))
                break
            case "medicaid":
                WebUI.click(findTestObject('Page_CURA Healthcare Service/input_Medicaid_programs'))
                break
            case "none":
                WebUI.click(findTestObject('Page_CURA Healthcare Service/input_None_programs'))
                break
        }
    }

    @And("selects visit date {string}")
    def select_date(String date) {
        WebUI.setText(findTestObject('Page_CURA Healthcare Service/input_Visit Date (Required)_visit_date'), date)
    }

    @And("enters comment {string}")
    def enter_comment(String comment) {
        WebUI.setText(findTestObject('Page_Appointment/txt_Comment'), comment)
    }

    @And("clicks on {string}")
    def click_book_button(String button) {
        if (button.equalsIgnoreCase("Book Appointment")) {
            WebUI.click(findTestObject('Page_Appointment/btn_BookAppointment'))
        }
    }

    @Then("the appointment confirmation page should display")
    def verify_confirmation_page() {
        WebUI.verifyElementPresent(findTestObject('Page_CURA Healthcare Service/textarea_Comment_comment'), 10)
    }

    @And("the confirmed facility should be {string}")
    def confirm_facility(String expected) {
        WebUI.verifyElementText(findTestObject('Page_Confirmation/txt_ConfirmFacility'), expected)
    }

    @And("the confirmed readmission should be {string}")
    def confirm_readmission(String expected) {
        WebUI.verifyElementText(findTestObject('Page_Confirmation/txt_ConfirmReadmission'), expected)
    }

    @And("the confirmed healthcare program should be {string}")
    def confirm_program(String expected) {
        WebUI.verifyElementText(findTestObject('Page_Confirmation/txt_ConfirmProgram'), expected)
    }

    @And("the confirmed visit date should be {string}")
    def confirm_date(String expected) {
        WebUI.verifyElementText(findTestObject('Page_Confirmation/txt_ConfirmVisitDate'), expected)
    }

    @And("the confirmed comment should be {string}")
    def confirm_comment(String expected) {
        WebUI.verifyElementText(findTestObject('Page_Confirmation/txt_ConfirmComment'), expected)
    }
}